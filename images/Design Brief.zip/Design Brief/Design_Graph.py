'''
Design Project
William Nguyen and Anthony Huynh
Period 2
'''
import matplotlib.pyplot as plt
import os.path 
import numpy as np
directory = os.path.dirname(os.path.abspath(__file__))
filename = os.path.join(directory, 'Data.csv')
datafile = open(filename,'r')
data = datafile.readlines()
champion_list=[]
ban = []
pick = []
win = []
for line in data[2:]:
    champion, bans, picks, wins = line.split(',')
    champion_list.append(champion)
    ban.append(bans)
    pick.append(picks)
    win.append(wins)
plt.figure(1)
number_of_champion = 55 #Number of all races listed in data
ind = np.arange(number_of_champion) #x-location for each bar
width=.275 #Sets width of each bar
bar1 = plt.bar(range(len(champion_list)), ban,width=width, color = '#333CFF')
bar2 = plt.bar(ind+width, pick,width=width, color = '#FF3333')
bar3= plt.bar(ind+width+.275, win,width=width, color = '#33FF80')
plt.title('Pick,ban, and win rate')
plt.ylabel('How often')
plt.xticks(range(len(champion_list)),champion_list, fontsize=10, rotation='vertical')
plt.legend((bar1[0], bar2[0], bar3[0]), ('Banned', 'Picked', 'Won')) 
plt.show()


   

    
    